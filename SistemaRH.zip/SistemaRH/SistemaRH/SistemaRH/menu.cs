﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaRH
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionario j2 = new funcionario();
            j2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            departamento j11 = new departamento();
            j11.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            salario j12= new salario();
            j12.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            beneficios j13 = new beneficios();
            j13.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TelaSistema j15 = new TelaSistema();
            j15.Show();
        }
    }
}
